<?php get_template_part('parts/header'); ?>
<section class="section-wrap">
    <h1> this is index.php </h1>
</section>
<?php get_template_part('parts/footer'); ?>