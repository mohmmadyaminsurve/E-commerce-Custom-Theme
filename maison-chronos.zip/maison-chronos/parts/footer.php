    <footer id="footer">
        <div class="main-footer section-wrap">
            <div class="logoinfo">
                <a href="<?php echo home_url(); ?>">
                    <?php
                    $image = get_field('primary_logo', 'option');
                    if (!empty($image)) : ?>
                        <img class="logo" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
                    <?php endif; ?>
                </a>
                <p>
                    <?php the_field('footer_description', 'option'); ?>
                </p>
            </div>
            <div class="contact-details">
                <h1>Contact Us</h1>
                <ul>
                    <li>
                        <div class="fa fa-phone"></div>
                        <a href="<?php the_field('primary_phone_number', 'option'); ?>"><?php the_field('primary_phone_number', 'option'); ?></a>
                    </li>
                    <li>
                        <div class="fa fa-envelope"></div>
                        <a href="<?php the_field('primary_e-mail_address', 'option'); ?>"><?php the_field('primary_e-mail_address', 'option'); ?></a>
                    </li>
                </ul>
            </div>
            <div class="com" data-aos="fade-up">
                <h1>Quick links</h1>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div class="com" data-aos="fade-up">
                <h1>Help</h1>
                <ul>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Terms and Conditions</a></li>
                    <li><a href="#">Return and Refunds</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                </ul>
            </div>
            <div class="info" data-aos="fade-up">
                <h1>Social Media</h1>
                <div class="sociallogos">
                    <div class="logobox">
                        <a href="#" class="fa fa-instagram"></a>
                        <a href="#" class="fa fa-linkedin"></a>
                        <a href="#" class="fa fa-facebook"></a>
                        <a href="#" class="fa fa-youtube-play"></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="flex-container section-wrap">
            <p class="cp">© <?php echo date("Y"); ?> Mohd Yamin. All Rights Reserved.</p>
            <img class="payment-icons" src="<?php echo get_template_directory_uri(); ?>/assests/images/payment-icons.svg" alt="" />
        </div>
    </footer>
    <?php wp_footer(); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" defer></script>
    <!-- Slick Slider -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" defer></script>
    <!--sweet aler cdn-->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11" defer></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assests/js/main.js" defer></script>
    </body>

    </html>