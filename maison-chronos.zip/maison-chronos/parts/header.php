<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Maison Chronos is your destination for premium luxury watches. Discover Swiss-made classics, GMT travel timepieces, and elegant everyday watches curated for every lifestyle.">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assests/css/style.css" />
    <!-- Preconnect for Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <!-- Slick CSS -->
    <link rel="preload" as="style" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" onload="this.onload=null;this.rel='stylesheet'">
    <noscript>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
    </noscript>
    <link rel="preload" as="style" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" onload="this.onload=null;this.rel='stylesheet'">
    <noscript>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">
    </noscript>
    <title>Maison Chronos – Premium Watch Store | Modern Timepieces & Luxury Wristwatches</title>
    <?php wp_head(); ?>
</head>

<body>
    <header>
        <!-- Adsterra Banner (728x90) -->
        <div style="display: flex; justify-content: center; margin: 10px 0;">
            <script type="text/javascript">
                atOptions = {
                    'key': '6c36ab9829b8f422f1a1139c4e0688b6',
                    'format': 'iframe',
                    'height': 90,
                    'width': 728,
                    'params': {}
                };
            </script>
            <script type="text/javascript" src="//www.highperformanceformat.com/6c36ab9829b8f422f1a1139c4e0688b6/invoke.js"></script>
        </div>
        <!-- Adsterra Social Bar -->
        <script type='text/javascript' src='//pl27048843.profitableratecpm.com/ae/ef/41/aeef4140b89b965c967340f3e9f052f2.js'></script>
        <div class="top-nav">
            <div class="section-wrap">
                <p class="white">Don't miss our holiday offer - up to <span class="bold">50% OFF!</span></p>
            </div>
        </div>
        <nav class="navbar">
            <div class="hamburger">
                <span class="bar" style="height: 1.5px"></span>
                <span class="bar" style="height: 1.5px"></span>
                <span class="bar" style="height: 1.5px"></span>
            </div>
            <div class="brandname">
                <a href="<?php echo home_url(); ?>">
                    <?php
                    $image = get_field('primary_logo', 'option');
                    if (!empty($image)) : ?>
                        <img class="logo" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" loading="lazy" />
                    <?php endif; ?>
                </a>
            </div>
            <?php wp_nav_menu(array(
                'theme_location' => 'primary-menu',
                'container_class' => 'navbar',
                'container'       => 'ul',
                'menu_class' => 'nav-menu',
                'add_li_class'  => 'nav-item'
            )); ?>
            <div class="icons-kit">
                <?php if (is_user_logged_in()) : ?>
                    <!-- Show My Account icon when logged in -->
                    <a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>">
                        <img class="header-login" src="<?php echo get_template_directory_uri(); ?>/assests/images/user-circle.svg" alt="My Account" loading="lazy" />
                    </a>
                <?php else : ?>
                    <!-- Show login icon when not logged in -->
                    <a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>">
                        <img class="header-login" src="<?php echo get_template_directory_uri(); ?>/assests/images/user-circle.svg" alt="Login" loading="lazy" />
                    </a>
                <?php endif; ?>
                <!-- Always show cart icon -->
                <?php echo do_shortcode('[custom_cart_icon]'); ?>
            </div>
        </nav>
    </header>