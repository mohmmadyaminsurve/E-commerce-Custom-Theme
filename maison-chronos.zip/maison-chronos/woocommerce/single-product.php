<?php get_template_part('parts/header'); ?>
<!--product detail section-->
<section id="prodetails" class="section-wrap">
    <?php
    // Start the Loop
    while (have_posts()) :
        the_post();
        global $product;
    ?>

        <div class="single-pro-image">
            <?php
            // Display the main product image
            if (has_post_thumbnail()) {
                echo '<img src="' . get_the_post_thumbnail_url() . '" width="100%" id="MainImg" alt="' . get_the_title() . '">';
            }
            ?>
            <div class="small-img-group">
                <?php
                // Display additional product images
                $attachment_ids = $product->get_gallery_image_ids();
                foreach ($attachment_ids as $attachment_id) {
                    $image_url = wp_get_attachment_url($attachment_id);
                    echo '<div class="small-img-col">
                        <img src="' . esc_url($image_url) . '" width="100%" class="small-img" alt="' . get_post_meta($attachment_id, '_wp_attachment_image_alt', true) . '">
                      </div>';
                }
                ?>
            </div>
        </div>

        <div class="single-pro-details">
            <h1 class="mb-20"><?php the_title(); ?></h1>
            <h5 class="mb-20"><?php echo $product->get_price_html(); ?></h5>

            <?php
            // Display product variations if any
            if ($product->is_type('variable')) {
                echo '<form class="variations_form cart" method="post" enctype="multipart/form-data" action="' . esc_url(wc_get_cart_url()) . '">
                    ' . wc_get_product_variation_attributes($product->get_id()) . '
                    <button type="submit" class="btn normal add_to_cart_button">Add to Cart</button>
                  </form>';
            } else {
                echo '<form class="cart  mb-20" method="post" enctype="multipart/form-data" action="' . esc_url(wc_get_cart_url()) . '">
                    <input type="hidden" name="add-to-cart" value="' . esc_attr($product->get_id()) . '" />
                    <input type="number" name="quantity" value="1" min="1">
                    <button type="submit" class="btn normal add_to_cart_button">Add to Cart</button>
                  </form>';
            }
            ?>
            <p class="mb-20"><?php echo wp_kses_post($product->get_description()); ?></p>
            <p class="fs-20"><span class="bold">Categor: </span> <?php echo wc_get_product_category_list($product->get_id()); ?></p>
        </div>

    <?php endwhile; // End of the loop. 
    ?>
</section>

<section id="products" class="section-wrap mb-40">
    <div class="flex-container">
        <?php
        // WooCommerce query to get products
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 3,
        );
        $loop = new WP_Query($args);

        if ($loop->have_posts()) :
            while ($loop->have_posts()) : $loop->the_post();
                global $product;
        ?>
                <div class="product-card">
                    <div class="product-bg">
                        <a href="<?php the_permalink(); ?>">
                            <?php
                            // always output an image—even if it's WooCommerce's placeholder
                            echo $product->get_image('medium', ['alt' => get_the_title()]);
                            ?>
                        </a>
                    </div>
                    <h5><?php the_title(); ?></h5>
                    <p class="price"><?php echo wp_kses_post(wc_price($product->get_price())); ?></p>
                    <div class="flex-container star-container">
                        <?php
                        $average = 4;

                        for ($i = 1; $i <= 5; $i++) {
                            if ($i <= $average) {
                                echo '<img class="fill-star" src="' . get_template_directory_uri() . '/assests/images/star.svg" alt="filled star" />';
                            } else {
                                echo '<img class="star" src="' . get_template_directory_uri() . '/assests/images/star.svg" alt="empty star" />';
                            }
                        }
                        ?>
                    </div>
                    <p class="category">
                        <?php
                        $categories = get_the_terms($product->get_id(), 'product_cat');
                        if ($categories && !is_wp_error($categories)) {
                            echo esc_html($categories[0]->name);
                        } else {
                            echo 'Uncategorized';
                        }
                        ?>
                    </p>
                    <a href="<?php echo esc_url('?add-to-cart=' . $product->get_id()); ?>" class="btn">Add to Cart</a>
                </div>
        <?php
            endwhile;
        else :
            echo '<p>No products found</p>';
        endif;
        wp_reset_postdata();
        ?>
    </div>

</section>



<!--custom javascript for add to cart-->
<script>
    // Redirect to cart page after adding to cart
    jQuery(document).ready(function($) {
        $('form.cart').on('submit', function(e) {
            e.preventDefault(); // Prevent default form submission
            var form = $(this);

            $.ajax({
                type: 'POST',
                url: form.attr('action'),
                data: form.serialize(), // Serialize form data
                success: function(response) {
                    window.location.href = "<?php echo esc_url(wc_get_cart_url()); ?>"; // Redirect to cart page
                }
            });
        });
    });
</script>

<?php get_template_part('parts/footer'); ?>