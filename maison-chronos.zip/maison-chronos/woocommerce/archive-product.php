<?php get_template_part('parts/header'); ?>

<section class="page-intro flex-container mb-40">
    <div class="section-wrap">
        <h1 class="fs-80">Shop</h1>
    </div>
</section>


<section id="products" class="section-wrap mb-40">
    <div class="flex-container">
        <?php
        // WooCommerce query to get products
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 3,
        );
        $loop = new WP_Query($args);

        if ($loop->have_posts()) :
            while ($loop->have_posts()) : $loop->the_post();
                global $product;
        ?>
                <div class="product-card">
                    <div class="product-bg">
                        <a href="<?php the_permalink(); ?>">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium'); ?>
                            <?php else : ?>
                                <img src="<?php echo esc_url(wc_placeholder_img_src()); ?>" alt="<?php the_title(); ?>">
                            <?php endif; ?>
                        </a>
                    </div>
                    <h5><?php the_title(); ?></h5>
                    <p class="price"><?php echo wp_kses_post(wc_price($product->get_price())); ?></p>
                    <div class="flex-container star-container">
                        <?php
                        $average = 4;

                        for ($i = 1; $i <= 5; $i++) {
                            if ($i <= $average) {
                                echo '<img class="fill-star" src="' . get_template_directory_uri() . '/assests/images/star.svg" alt="filled star" />';
                            } else {
                                echo '<img class="star" src="' . get_template_directory_uri() . '/assests/images/star.svg" alt="empty star" />';
                            }
                        }
                        ?>
                    </div>
                    <p class="category">
                        <?php
                        $categories = get_the_terms($product->get_id(), 'product_cat');
                        if ($categories && !is_wp_error($categories)) {
                            echo esc_html($categories[0]->name);
                        } else {
                            echo 'Uncategorized';
                        }
                        ?>
                    </p>
                    <a href="<?php echo esc_url('?add-to-cart=' . $product->get_id()); ?>" class="btn">Add to Cart</a>
                </div>
        <?php
            endwhile;
        else :
            echo '<p>No products found</p>';
        endif;
        wp_reset_postdata();
        ?>
    </div>

</section>
<!--newsleeter section-->
<section id="newsletter">
    <div class="section-wrap">
        <div class="flex-container">
            <div class="newstext white">
                <h4>Sign Up for Newsletters</h4>
                <p>Get Email updates about our latest shop and <span> special offers.</span></p>
            </div>
            <div class="form">
                <input type="text" placeholder="Your email address" />
                <button class="btn normal">Sign Up</button>
            </div>
        </div>
    </div>
</section>
<?php get_template_part('parts/footer'); ?>